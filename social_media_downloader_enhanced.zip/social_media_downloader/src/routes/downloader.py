from flask import Blueprint, request, jsonify, send_file
import os
import tempfile
import yt_dlp
import re
import uuid
import requests
from bs4 import BeautifulSoup

downloader_bp = Blueprint('downloader', __name__)

# Create a temporary directory for downloads
TEMP_DOWNLOAD_DIR = os.path.join(tempfile.gettempdir(), 'social_media_downloads')
os.makedirs(TEMP_DOWNLOAD_DIR, exist_ok=True)

def is_valid_instagram_url(url):
    """Check if the URL is a valid Instagram URL."""
    instagram_pattern = r'^https?://(www\.)?instagram\.com/(p|reel|stories)/[\w-]+/?.*$'
    return bool(re.match(instagram_pattern, url))

def is_valid_facebook_url(url):
    """Check if the URL is a valid Facebook URL."""
    facebook_pattern = r'^https?://(www\.)?(facebook\.com|fb\.watch)/.*$'
    return bool(re.match(facebook_pattern, url))

@downloader_bp.route('/download', methods=['POST'])
def download_content():
    """Download content from Instagram or Facebook."""
    data = request.get_json()
    
    if not data or 'url' not in data:
        return jsonify({'error': 'URL is required'}), 400
    
    url = data['url'].strip()
    
    # Validate URL
    if not (is_valid_instagram_url(url) or is_valid_facebook_url(url)):
        return jsonify({'error': 'Invalid Instagram or Facebook URL'}), 400
    
    try:
        # Generate a unique filename
        unique_id = str(uuid.uuid4())
        output_path = os.path.join(TEMP_DOWNLOAD_DIR, unique_id)
        
        # Configure yt-dlp options
        ydl_opts = {
            'format': 'best',
            'outtmpl': output_path + '.%(ext)s',
            'quiet': True,
            'no_warnings': True,
            'ignoreerrors': False,
        }
        
        # Download the content
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            
            if not info:
                return jsonify({'error': 'Failed to extract information from URL'}), 400
                
            # Get the downloaded file path
            if 'entries' in info:
                # Playlist
                info = info['entries'][0]
                
            filename = ydl.prepare_filename(info)
            
            # Get file extension and content type
            _, ext = os.path.splitext(filename)
            ext = ext.lstrip('.')
            
            content_type = 'video/mp4'
            if ext in ['jpg', 'jpeg', 'png']:
                content_type = f'image/{ext}'
            
            # Return file information
            return jsonify({
                'success': True,
                'file_id': unique_id,
                'filename': os.path.basename(filename),
                'content_type': content_type,
                'title': info.get('title', 'Download'),
                'platform': 'Instagram' if 'instagram' in url else 'Facebook'
            })
            
    except Exception as e:
        return jsonify({'error': f'Download failed: {str(e)}'}), 500

@downloader_bp.route('/file/<file_id>', methods=['GET'])
def get_file(file_id):
    """Serve the downloaded file."""
    try:
        # Find the file with the given ID
        for filename in os.listdir(TEMP_DOWNLOAD_DIR):
            if filename.startswith(file_id):
                file_path = os.path.join(TEMP_DOWNLOAD_DIR, filename)
                return send_file(file_path, as_attachment=True)
        
        return jsonify({'error': 'File not found'}), 404
    except Exception as e:
        return jsonify({'error': f'Failed to serve file: {str(e)}'}), 500

@downloader_bp.route('/info', methods=['POST'])
def get_content_info():
    """Get information about the content without downloading."""
    data = request.get_json()
    
    if not data or 'url' not in data:
        return jsonify({'error': 'URL is required'}), 400
    
    url = data['url'].strip()
    
    # Validate URL
    if not (is_valid_instagram_url(url) or is_valid_facebook_url(url)):
        return jsonify({'error': 'Invalid Instagram or Facebook URL'}), 400
    
    try:
        # Configure yt-dlp options
        ydl_opts = {
            'format': 'best',
            'quiet': True,
            'no_warnings': True,
            'skip_download': True,
        }
        
        # Extract information
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            
            if not info:
                return jsonify({'error': 'Failed to extract information from URL'}), 400
            
            # Return content information
            return jsonify({
                'success': True,
                'title': info.get('title', 'Unknown'),
                'thumbnail': info.get('thumbnail'),
                'duration': info.get('duration'),
                'platform': 'Instagram' if 'instagram' in url else 'Facebook',
                'type': 'video' if info.get('duration') else 'image'
            })
            
    except Exception as e:
        return jsonify({'error': f'Failed to get information: {str(e)}'}), 500

@downloader_bp.route('/cleanup', methods=['POST'])
def cleanup_files():
    """Clean up old downloaded files."""
    try:
        # Delete files older than 1 hour
        import time
        current_time = time.time()
        one_hour_ago = current_time - 3600
        
        deleted_count = 0
        for filename in os.listdir(TEMP_DOWNLOAD_DIR):
            file_path = os.path.join(TEMP_DOWNLOAD_DIR, filename)
            if os.path.isfile(file_path) and os.path.getmtime(file_path) < one_hour_ago:
                os.remove(file_path)
                deleted_count += 1
        
        return jsonify({'success': True, 'deleted_count': deleted_count})
    except Exception as e:
        return jsonify({'error': f'Cleanup failed: {str(e)}'}), 500
