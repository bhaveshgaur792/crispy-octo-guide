// Google AdSense Integration Code
// This file contains the code needed to integrate Google AdSense into the social media downloader application

// Step 1: Add this script to the <head> section of index.html
const googleAdSenseHeadCode = `
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-XXXXXXXXXXXXXXXX"
     crossorigin="anonymous"></script>
`;

// Step 2: Replace the placeholder ad containers with these AdSense units
// For horizontal banner ads (728x90)
const horizontalAdCode = `
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:90px"
     data-ad-client="ca-pub-XXXXXXXXXXXXXXXX"
     data-ad-slot="XXXXXXXXXX"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
`;

// For responsive ads (adapts to container size)
const responsiveAdCode = `
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-XXXXXXXXXXXXXXXX"
     data-ad-slot="XXXXXXXXXX"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
`;

// For square/rectangle ads (300x250)
const rectangleAdCode = `
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:250px"
     data-ad-client="ca-pub-XXXXXXXXXXXXXXXX"
     data-ad-slot="XXXXXXXXXX"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
`;

// Step 3: Add this code for interstitial ads (shown after download)
const interstitialAdCode = `
function showInterstitialAd() {
    // This would be replaced with actual interstitial ad code from Google AdSense
    console.log('Showing interstitial ad');
    
    // For demonstration purposes, we're simulating an ad display
    const adOverlay = document.createElement('div');
    adOverlay.style.position = 'fixed';
    adOverlay.style.top = '0';
    adOverlay.style.left = '0';
    adOverlay.style.width = '100%';
    adOverlay.style.height = '100%';
    adOverlay.style.backgroundColor = 'rgba(0, 0, 0, 0.8)';
    adOverlay.style.zIndex = '9999';
    adOverlay.style.display = 'flex';
    adOverlay.style.alignItems = 'center';
    adOverlay.style.justifyContent = 'center';
    adOverlay.style.flexDirection = 'column';
    
    const adContainer = document.createElement('div');
    adContainer.style.width = '300px';
    adContainer.style.height = '250px';
    adContainer.style.backgroundColor = '#f0f0f0';
    adContainer.style.display = 'flex';
    adContainer.style.alignItems = 'center';
    adContainer.style.justifyContent = 'center';
    adContainer.innerHTML = '<p>Advertisement</p>';
    
    const closeButton = document.createElement('button');
    closeButton.textContent = 'Close Ad';
    closeButton.style.marginTop = '20px';
    closeButton.style.padding = '10px 20px';
    closeButton.style.backgroundColor = '#ff416c';
    closeButton.style.color = 'white';
    closeButton.style.border = 'none';
    closeButton.style.borderRadius = '5px';
    closeButton.style.cursor = 'pointer';
    
    closeButton.addEventListener('click', function() {
        document.body.removeChild(adOverlay);
    });
    
    adOverlay.appendChild(adContainer);
    adOverlay.appendChild(closeButton);
    
    document.body.appendChild(adOverlay);
    
    // In a real implementation, this would be:
    // (adsbygoogle = window.adsbygoogle || []).push({});
}
`;

// Step 4: Implementation instructions
const implementationInstructions = `
Implementation Instructions:

1. Add the Google AdSense script to the <head> section of index.html
   - Replace XXXXXXXXXXXXXXXX with your actual Google AdSense Publisher ID

2. Replace the placeholder ad containers in index.html with the appropriate AdSense code:
   - For ad-slot-1 and ad-slot-3: Use horizontalAdCode (728x90)
   - For ad-slot-2 and ad-slot-4: Use rectangleAdCode (300x250) or responsiveAdCode
   
3. Implement the interstitial ad function:
   - Add the interstitialAdCode to your JavaScript
   - Call showInterstitialAd() after a successful download
   
4. Important Google AdSense Policy Reminders:
   - Do not click on your own ads
   - Do not encourage users to click on ads
   - Do not place ads in a way that they might be confused with site content
   - Ensure ads are clearly labeled as "Advertisement"
   - Do not place more than 3 ad units per page
   - Follow all Google AdSense program policies: https://support.google.com/adsense/answer/48182
`;

// Export all code snippets and instructions
module.exports = {
    googleAdSenseHeadCode,
    horizontalAdCode,
    responsiveAdCode,
    rectangleAdCode,
    interstitialAdCode,
    implementationInstructions
};
